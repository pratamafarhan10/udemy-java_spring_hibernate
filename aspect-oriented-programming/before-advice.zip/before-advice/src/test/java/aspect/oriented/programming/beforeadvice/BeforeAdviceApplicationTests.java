package aspect.oriented.programming.beforeadvice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeforeAdviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
