package aspect.oriented.programming.beforeadvice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeforeAdviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeforeAdviceApplication.class, args);
	}

}
