package aspect.oriented.programming.afterreturning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AfterReturningApplication {

	public static void main(String[] args) {
		SpringApplication.run(AfterReturningApplication.class, args);
	}

}
