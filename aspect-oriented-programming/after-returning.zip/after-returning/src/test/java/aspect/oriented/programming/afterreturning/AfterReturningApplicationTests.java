package aspect.oriented.programming.afterreturning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AfterReturningApplicationTests {

	@Test
	void contextLoads() {
	}

}
