package aspect.oriented.programming.around;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AroundApplicationTests {

	@Test
	void contextLoads() {
	}

}
