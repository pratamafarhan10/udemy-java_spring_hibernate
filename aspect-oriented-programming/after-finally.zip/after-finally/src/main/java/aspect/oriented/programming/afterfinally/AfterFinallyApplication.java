package aspect.oriented.programming.afterfinally;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AfterFinallyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AfterFinallyApplication.class, args);
	}

}
