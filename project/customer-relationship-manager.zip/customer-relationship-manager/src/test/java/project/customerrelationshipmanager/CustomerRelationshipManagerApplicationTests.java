package project.customerrelationshipmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerRelationshipManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
