package person.controller;

import java.util.List;
import java.util.Optional;

import person.exception.PersonNotFoundException;
import person.model.Person;
import person.service.PersonService;

// @RestMapping("person/")
// @RestController
public class PersonController {
    private final PersonService personService;

    // @Autowired
    public PersonController(PersonService personService){
        this.personService = personService;
    }

    // @PostMapping("/")
    public int addPerson(Person person){
        return this.personService.addPerson(person);
    }

    // @GetMapping("/")
    public List<Person> getPerson(){
        return this.personService.getPerson();
    }

    // @GetMapping("/{id}")
    // public Optional<Person> getPersonById(@PathVariable String id)
    public Optional<Person> getPersonById(String id) throws PersonNotFoundException{
        return this.personService.getPersonById(id);
    }

    // @PutMapping("/{id}")
    // public int updatePersonById(@PathVariable String id, @RequestBody Person person)
    public int updatePersonById(String id, Person person){
        return this.personService.updatePersonById(id, person);
    }

    // @DeleteMapping("/{id}")
    // public int deletePersonById(@PathVariable String id)
    public int deletePersonById(String id){
        return this.personService.deletePersonById(id);
    }
}
