package person.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import person.exception.PersonNotFoundException;
import person.model.Person;

// @Repository
public class PersonRepository implements PersonInterface {
    public List<Person> persons = new ArrayList<>();

    public PersonRepository() {
        Person person1 = new Person("john", 20);
        this.persons.add(person1);
    }

    @Override
    public int addPerson(Person person) {
        this.persons.add(new Person(person));
        return 1;
    }

    @Override
    public List<Person> getPerson() {
        return this.persons;
    }

    @Override
    public Optional<Person> getPersonById(String id) throws PersonNotFoundException {
        Optional<Person> res = this.persons.stream().filter(p -> p.getId().equalsIgnoreCase(id)).findFirst();

        if (res.isEmpty()) {
            throw new PersonNotFoundException(id);
        }

        return res;
    }

    @Override
    public int updatePersonById(String id, Person person) {
        return this.getPersonById(id).map(p -> {
            int indexOfPerson = this.persons.indexOf(p);
            p.setAge(person.getAge());
            p.setName(person.getName());
            this.persons.set(indexOfPerson, p);

            return 1;
        }).orElse(0);
    }

    @Override
    public int deletePersonById(String id) {
        Optional<Person> person = this.getPersonById(id);
        
        this.persons.remove(person.get());
        return 1;
    }
}
