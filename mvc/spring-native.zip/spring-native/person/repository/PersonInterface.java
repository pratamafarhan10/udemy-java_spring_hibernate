package person.repository;

import java.util.List;
import java.util.Optional;

import person.model.Person;

public interface PersonInterface {
    // Add
    public int addPerson(Person person);

    // Get all
    public List<Person> getPerson();

    // Get one
    public Optional<Person> getPersonById(String id);

    // Update one
    public int updatePersonById(String id, Person person);

    // Delete one
    public int deletePersonById(String id);
}
