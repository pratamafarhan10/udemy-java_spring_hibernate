package person.service;

import java.util.List;
import java.util.Optional;

import person.exception.PersonNotFoundException;
import person.model.Person;
import person.repository.PersonRepository;

// @Service
public class PersonService {
    private final PersonRepository personRepository;

    // @Autowired
    public PersonService(PersonRepository personRepository){
        this.personRepository = personRepository;
    }

    public int addPerson(Person person){
        return this.personRepository.addPerson(person);
    }

    public List<Person> getPerson(){
        return this.personRepository.getPerson();
    }

    public Optional<Person> getPersonById(String id) throws PersonNotFoundException{
        return this.personRepository.getPersonById(id);
    }

    public int updatePersonById(String id, Person person){
        return this.personRepository.updatePersonById(id, person);
    }

    public int deletePersonById(String id){
        return this.personRepository.deletePersonById(id);
    }
}
