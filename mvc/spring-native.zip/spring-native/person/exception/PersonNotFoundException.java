package person.exception;

public class PersonNotFoundException extends RuntimeException{
    private final String message;

    public PersonNotFoundException(String id){
        this.message = "Id = " + id + " not found";
    }

    public String getMessage() {
        return this.message;
    }
}
