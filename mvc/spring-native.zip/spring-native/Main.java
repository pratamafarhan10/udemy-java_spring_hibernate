import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import person.controller.PersonController;
import person.model.Person;
import person.repository.PersonRepository;
import person.service.PersonService;

public class Main {
    private static PersonController personController = new PersonController(new PersonService(new PersonRepository()));

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        boolean isContinue = true;
        while (isContinue) {
            System.out.println("\nPilih menu: ");
            System.out.println("1. Add person");
            System.out.println("2. Get person");
            System.out.println("3. Get person by id");
            System.out.println("4. Update person by id");
            System.out.println("5. Delete person by id");
            System.out.print("\nAnswer: ");
            int menu = scan.nextInt();
            scan.nextLine();
            switch (menu) {
                case 1:
                    addPerson(scan);
                    break;
                case 2:
                    getPerson(scan);
                    break;
                case 3:
                    getPersonById(scan);
                    break;
                case 4:
                    updatePersonById(scan);
                    break;
                case 5:
                    deletePersonById(scan);
                    break;
                default:
                    continue;
            }

            System.out.print("\nContinue? ");
            String answer = scan.nextLine();
            isContinue = answer.equalsIgnoreCase("y") ? true : false;
        }
        scan.close();
    }

    public static void addPerson(Scanner scan) {
        System.out.println("====== Add Person ======");
        System.out.print("Masukkan name: ");
        String name = scan.nextLine();
        System.out.print("Masukkan age: ");
        int age = scan.nextInt();
        scan.nextLine();

        Person person = new Person(name, age);

        int result = personController.addPerson(person);

        System.out.println(result == 0 ? "GAGAL MEMASUKKAN DATA" : "BERHASIL MEMASUKKAN DATA");
    }

    public static void getPerson(Scanner scan) {
        System.out.println("====== Get All Person ======");
        List<Person> persons = personController.getPerson();
        persons.forEach(person -> System.out.println(person));
    }

    public static void getPersonById(Scanner scan) {
        System.out.println("====== Get Person By Id ======");
        System.out.print("Masukkan id: ");
        String id = scan.nextLine();

        Optional<Person> person = personController.getPersonById(id);

        System.out.println(person.toString());
    }

    public static void updatePersonById(Scanner scan) {
        System.out.println("====== Update Person By Id ======");
        System.out.print("Masukkan id: ");
        String id = scan.nextLine();
        System.out.print("Masukkan name: ");
        String name = scan.nextLine();
        System.out.print("Masukkan age: ");
        int age = scan.nextInt();
        scan.nextLine();

        Person person = new Person(name, age);

        int res = personController.updatePersonById(id, person);
        System.out.println(res == 0 ? "GAGAL UPDATE DATA" : "BERHASIL UPDATE DATA");
    }

    public static void deletePersonById(Scanner scan) {
        System.out.println("====== Delete Person By Id ======");
        System.out.print("Masukkan id: ");
        String id = scan.nextLine();

        int res = personController.deletePersonById(id);

        System.out.println(res == 0 ? "GAGAL DELETE DATA" : "BERHASIL DELETE DATA");
    }
}