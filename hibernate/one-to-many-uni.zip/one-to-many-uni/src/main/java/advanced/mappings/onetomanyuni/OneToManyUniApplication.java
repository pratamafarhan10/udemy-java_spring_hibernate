package advanced.mappings.onetomanyuni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneToManyUniApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneToManyUniApplication.class, args);
	}

}
