package advanced.mappings.onetomanyuni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToManyUniApplicationTests {

	@Test
	void contextLoads() {
	}

}
