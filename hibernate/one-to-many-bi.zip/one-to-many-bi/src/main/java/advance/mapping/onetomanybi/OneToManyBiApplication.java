package advance.mapping.onetomanybi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneToManyBiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneToManyBiApplication.class, args);
	}

}
