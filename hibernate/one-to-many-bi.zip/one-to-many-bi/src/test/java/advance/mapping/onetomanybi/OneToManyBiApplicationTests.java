package advance.mapping.onetomanybi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToManyBiApplicationTests {

	@Test
	void contextLoads() {
	}

}
