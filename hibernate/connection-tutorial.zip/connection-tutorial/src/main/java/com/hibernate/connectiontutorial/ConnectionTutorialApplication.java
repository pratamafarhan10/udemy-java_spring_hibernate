package com.hibernate.connectiontutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnectionTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConnectionTutorialApplication.class, args);
	}

}
