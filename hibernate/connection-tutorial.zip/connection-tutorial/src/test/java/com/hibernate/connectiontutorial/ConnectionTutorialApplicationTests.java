package com.hibernate.connectiontutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectionTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
